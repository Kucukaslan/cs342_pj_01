21901779 Muhammed Can Küçükaslan
21902298 Giray Akyol

Using "make" command would compile all the executable programs.
"make all" command would compile the programs of part A.
"make allt" command would compile the programs of part B. 
"make clean" remove the programs